"""Score the frozen math primary pair and keep same-depth attribution exploratory."""

import argparse
import copy
import hashlib
import json
from pathlib import Path

from score_math import score


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--records", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    assert plan["stage"] == "confirmation" and len(plan["arms"]) == 3
    assert (
        hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        == plan["confirmation_math_scorer_sha256"]
    )
    baseline, candidate, matched_off = plan["arms"]
    assert baseline["depth"] == 4 and not baseline["guidance"]
    assert candidate["guidance"] and candidate["depth"] == matched_off["depth"]
    assert not matched_off["guidance"]
    protocol_sha = hashlib.sha256(args.plan.read_bytes()).hexdigest()
    records = [
        json.loads(line) for line in args.records.read_text().splitlines() if line
    ]
    assert all(row["protocol_sha256"] == protocol_sha for row in records)
    expected = {row["problem_id"]: row["task"] for row in plan["records"]}
    assert len(expected) == len(plan["records"])
    arms = {row["arm_id"] for row in plan["arms"]}
    assert len(arms) == 3
    assert len({(row["arm_id"], row["problem_id"]) for row in records}) == len(records)
    assert all(
        row["arm_id"] in arms and expected[row["problem_id"]] == row["task"]
        for row in records
    )
    plan = copy.deepcopy(plan)
    plan["records"] = [row for row in plan["records"] if row["task"] == "gsm8k"]
    assert len(plan["records"]) == plan["final_n_by_task"]["gsm8k"]
    math = [row for row in records if row["task"] == "gsm8k"]
    result = score(plan, math)
    result["comparisons"] = [
        row for row in result["comparisons"] if row["candidate"] == candidate["arm_id"]
    ]
    result["comparisons"][0]["scope"] = (
        f"primary mathematics confirmation; frozen family M{plan['quality']['family_comparisons']}"
    )
    plan["arms"] = [matched_off, candidate]
    pair = score(
        plan,
        [
            row
            for row in math
            if row["arm_id"] in {matched_off["arm_id"], candidate["arm_id"]}
        ],
    )["comparisons"][0]
    pair["scope"] = (
        "exploratory same-depth attribution; not an additional confirmatory claim"
    )
    result["comparisons"].append(pair)
    result.update(
        protocol_sha256=protocol_sha,
        records_sha256=hashlib.sha256(args.records.read_bytes()).hexdigest(),
        summary_driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    )
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(
        json.dumps({"arms": result["arms"], "comparisons": result["comparisons"]}),
        flush=True,
    )


if __name__ == "__main__":
    main()
