"""Export exact frozen code completions; missing generation blocks complete scoring."""

import argparse
import hashlib
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--records", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    assert plan["stage"] == "confirmation"
    assert (
        hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        == plan["code_export_driver_sha256"]
    )
    component = plan["code_component"]
    assert component["status"] == "FROZEN_BEFORE_OUTPUTS"
    expected = {
        row["problem_id"]: row
        for row in plan["records"]
        if row["task"] == "humanevalplus"
    }
    assert len(expected) == component["n"] == 148
    plan_sha = hashlib.sha256(args.plan.read_bytes()).hexdigest()
    rows = [json.loads(line) for line in args.records.read_text().splitlines() if line]
    assert all(row["protocol_sha256"] == plan_sha for row in rows)
    global_ids = {row["problem_id"]: row["task"] for row in plan["records"]}
    assert len(global_ids) == len(plan["records"])
    assert len({(row["arm_id"], row["problem_id"]) for row in rows}) == len(rows)
    assert all(global_ids[row["problem_id"]] == row["task"] for row in rows)
    by_arm = {arm["arm_id"]: {} for arm in plan["arms"]}
    for row in rows:
        assert row["arm_id"] in by_arm
        if row["task"] != "humanevalplus":
            continue
        assert row["problem_id"] in expected
        arm = by_arm[row["arm_id"]]
        assert row["problem_id"] not in arm
        arm[row["problem_id"]] = row
    args.output.mkdir(exist_ok=False)
    summaries = []
    for arm_id, generated in by_arm.items():
        complete = len(generated) == 148 and all(
            row["runtime_status"] == "COMPLETE" for row in generated.values()
        )
        receipt = {
            "arm_id": arm_id,
            "required_n": 148,
            "received_n": len(generated),
            "completed_n": sum(
                row["runtime_status"] == "COMPLETE" for row in generated.values()
            ),
            "status": "EXPORTED_UNSCORED" if complete else "INCOMPLETE_GENERATION",
        }
        if complete:
            samples = args.output / f"{arm_id}.jsonl"
            with samples.open("x") as stream:
                for problem_id, task in expected.items():
                    row = generated[problem_id]
                    assert row["prompt_token_ids"] == task["prompt_ids"]
                    stream.write(
                        json.dumps(
                            {
                                "task_id": task["source_id"],
                                "completion": row["scoring_text"],
                            },
                            ensure_ascii=False,
                        )
                        + "\n"
                    )
            receipt.update(
                samples=str(samples),
                samples_sha256=hashlib.sha256(samples.read_bytes()).hexdigest(),
            )
        summaries.append(receipt)
    result = {
        "status": "EXPORTED_UNSCORED"
        if all(row["status"] == "EXPORTED_UNSCORED" for row in summaries)
        else "INCOMPLETE",
        "protocol_sha256": plan_sha,
        "records_sha256": hashlib.sha256(args.records.read_bytes()).hexdigest(),
        "scorer_sha256": component["scorer_sha256"],
        "denominator": 148,
        "repairs": "NONE",
        "arms": summaries,
    }
    with (args.output / "export.json").open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
