"""Run frozen independent generation, then export scores for offbox code execution."""

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path


def dump(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--support", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    args = parser.parse_args()
    work = args.work
    plan = json.loads((work / "data/plan.json").read_text())
    ready = json.loads((work / "ready.json").read_text())
    assert plan["stage"] == "confirmation"
    assert plan["selection"]["status"] == "SELECTED"
    assert plan["selection"]["fixed_work_cost_evidence_sha256"]
    assert plan["final_n_by_task"] == {"gsm8k": 505, "humanevalplus": 148}
    assert ready["w2_gate"]["status"] == "PASS"
    assert plan["dtype"] == ready["w2_gate"]["dtype"] == "float32"
    assert (
        plan["attention_backend"] == ready["w2_gate"]["attention_backend"] == "triton"
    )
    assert plan["source_sha"] == ready["w2_gate"]["source_sha"]
    assert plan["model_revision"] == ready["w2_gate"]["model_revision"]
    assert plan["generated_token_budget"] == 3 * (505 + 148) * 1024
    evidence = work / "evidence"
    evidence.mkdir(exist_ok=False)
    receipt = {
        "pid": os.getpid(),
        "started_unix": time.time(),
        "children": [],
        "status": "RUNNING",
    }
    env = dict(
        os.environ,
        PYTHONDONTWRITEBYTECODE="1",
        CUDA_VISIBLE_DEVICES="",
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        HF_HOME=str(work / "cache/hf"),
        XDG_CACHE_HOME=str(work / "cache"),
        CUDA_CACHE_PATH=str(work / "cache/cuda"),
        TRITON_CACHE_DIR=str(work / "cache/triton"),
    )

    def child(name: str, arguments: list[str], cuda: bool = False) -> int:
        assert (
            time.time() + plan["batch_finish_allowance_seconds"]
            < plan["archive_by_unix"]
        )
        with (evidence / f"{name}.log").open("x") as log:
            process = subprocess.Popen(
                [str(args.python), *arguments],
                stdout=log,
                stderr=subprocess.STDOUT,
                env={**env, "CUDA_VISIBLE_DEVICES": "0" if cuda else ""},
            )
            row = {"name": name, "pid": process.pid, "started_unix": time.time()}
            receipt["children"].append(row)
            dump(evidence / "window.json", receipt)
            row.update(returncode=process.wait(), finished_unix=time.time())
            dump(evidence / "window.json", receipt)
            return row["returncode"]

    driver = str(work / "harness/generate_quality_fp32.py")
    common = ["--source", str(args.source), "--support", str(args.support)]
    frozen = evidence / "confirmation-frozen.json"
    code = child(
        "tokenize",
        [
            driver,
            "tokenize",
            *common,
            "--plan",
            str(work / "data/plan.json"),
            "--data",
            str(work / "data/data.json"),
            "--output",
            str(frozen),
        ],
    )
    if code == 0:
        tokenized = json.loads(frozen.read_text())
        cohorts = []
        block_bytes = tokenized["capacity"]["block_bytes"]
        block = tokenized["cache_config"]["block_size"]
        available = tokenized["cache_config"]["kv_cache_memory_bytes"] // block_bytes
        for task in tokenized["tasks"]:
            records = [r for r in tokenized["records"] if r["task"] == task]
            for start in range(0, len(records), tokenized["batch_limit"]):
                rows = records[start : start + tokenized["batch_limit"]]
                spans = [
                    len(r["prompt_ids"]) + tokenized["max_new_tokens"] - 1 for r in rows
                ]
                required = sum((n + block - 1) // block for n in spans)
                assert required <= available
                cohorts.append(
                    {
                        "task": task,
                        "start": start,
                        "configured_C": len(rows),
                        "worst_span_tokens": max(spans),
                        "required_blocks": required,
                        "available_blocks": available,
                        "required_bytes": required * block_bytes,
                    }
                )
        tokenized["capacity"]["cohorts"] = cohorts
        tokenized["capacity"]["scope"] = (
            "Actual per-task cohort bounds frozen before GPU outputs; A/S not inferred"
        )
        dump(frozen, tokenized)
        receipt.update(
            frozen_protocol_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(),
            frozen_before_output_unix=time.time(),
            final_n_by_task=tokenized["final_n_by_task"],
        )
        dump(evidence / "window.json", receipt)
        code = child(
            "confirmation",
            [
                driver,
                "generate",
                *common,
                "--plan",
                str(frozen),
                "--output",
                str(evidence / "confirmation"),
            ],
            True,
        )
    records_path = evidence / "confirmation/records.jsonl"
    if code == 0:
        code = child(
            "score-math",
            [
                str(work / "harness/score_confirmation_math.py"),
                "--plan",
                str(frozen),
                "--records",
                str(records_path),
                "--output",
                str(evidence / "confirmation-math-scored.json"),
            ],
        )
    if code == 0:
        code = child(
            "export-code",
            [
                str(work / "harness/export_confirmation_code.py"),
                "--plan",
                str(frozen),
                "--records",
                str(records_path),
                "--output",
                str(evidence / "code-export"),
            ],
        )
    receipt.update(
        status="COMPLETE" if code == 0 else "FAILED",
        returncode=code,
        finished_unix=time.time(),
    )
    dump(evidence / "window.json", receipt)
    print(json.dumps(receipt), flush=True)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
