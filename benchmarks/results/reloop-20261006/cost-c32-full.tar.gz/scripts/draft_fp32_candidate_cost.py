"""Unstaged FP32 cost draft: freeze a candidate/protocol and obtain a grant first."""

import argparse
import hashlib
import json
import math
import subprocess
from dataclasses import asdict
from pathlib import Path

import torch
import vllm_rlt
from fp32_candidate_cost_trial import install_neutral_counters, run
from vllm_rlt import (
    LLM,
    CacheConfig,
    ExecutionConfig,
    LoopCDParams,
    SamplingParams,
    SchedulerConfig,
)
from vllm_rlt.models import load_tokenizer

ROOT = Path(__file__).resolve().parents[1]
SOURCE = "e8aa1ee57734bc5c1118c143ebdb68d0b53210a1"
PIN = "574fa66cb8bf5abdc979642d01cf2b79b16bfab1"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--case", choices=("B16C32", "B32C64"), required=True)
    parser.add_argument("--arm", choices=("A", "B", "C"), required=True)
    parser.add_argument("--fresh", type=int, choices=(0, 1), required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    protocol = json.loads(args.protocol.read_text())
    candidate = json.loads(args.candidate.read_text())
    assert protocol["state"] == "FROZEN_FP32_CANDIDATE_COST"
    assert candidate["state"] == "PROVISIONAL_FOR_COST"
    assert digest(args.candidate) == protocol["candidate_sha256"]
    assert protocol["source_sha"] == candidate["source_sha"] == SOURCE
    assert protocol["dtype"] == candidate["dtype"] == "float32"
    assert protocol["attention_backend"] == candidate["attention_backend"] == "triton"
    assert candidate["decode_depth"] in (2, 3) and 0 < candidate["strength"] <= 1
    assert protocol["warmups"] == protocol["measurements"] == 5
    assert protocol["input_length"] == 512 and protocol["output_tokens"] == 128
    assert protocol["prefill_depth"] == 4 and protocol["kv_gib"] == 64
    assert protocol["requests_per_trial"] == "C"
    assert protocol["cuda_graphs"] is False
    assert protocol["request_scope"] == "INITIAL_C_TOTAL_C_NO_REFILL"
    assert protocol["model_revision"] == PIN
    gate_path = (
        ROOT / "evidence/qualification-w2-fp32-triton-v1/w2-fp32-triton-continuation/result.json"
    )
    gate = json.loads(gate_path.read_text())
    assert digest(gate_path) == protocol["fp32_w2_gate_sha256"]
    assert gate["status"] == "PASS" and gate["dtype"] == "float32"
    assert gate["atol"] == gate["rtol"] == 1e-4 and len(gate["cases"]) == 12
    assert Path(vllm_rlt.__file__).resolve().parents[1] == ROOT / "source"
    assert (
        subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT / "source", text=True
        ).strip()
        == SOURCE
    )
    assert not subprocess.check_output(
        ["git", "status", "--porcelain"], cwd=ROOT / "source", text=True
    ).strip()
    assert not torch.cuda.is_initialized()
    label = f"{args.case}-fresh{args.fresh}-{args.arm}"
    assert args.output.name == label and "." not in label
    manifest_path = args.output.parent / (label + ".manifest.json")
    assert not args.output.exists() and not manifest_path.exists()
    batch, concurrency = (16, 32) if args.case == "B16C32" else (32, 64)
    depth = 4 if args.arm == "A" else candidate["decode_depth"]
    enabled = args.arm == "C"
    execution = ExecutionConfig(loopcd=enabled, prefill_depth=4, cuda_graphs=False)
    sampling = SamplingParams(
        max_tokens=128,
        temperature=0.0,
        min_loops=depth,
        max_loops=depth,
        ignore_eos=True,
        loopcd=LoopCDParams(strength=candidate["strength"], implementation="two_head")
        if enabled
        else None,
    )
    # A and B disable both the capability and request guidance.
    assert enabled or (execution.loopcd is False and sampling.loopcd is None)
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model = ROOT / "models/ouro-574fa66c"
    cache_config = CacheConfig(kv_cache_memory_bytes=64 * 1024**3)
    llm = LLM(
        str(model),
        revision=PIN,
        device="cuda",
        dtype=torch.float32,
        attention_backend="triton",
        cache_config=cache_config,
        scheduler_config=SchedulerConfig(
            max_num_seqs=batch, max_num_batched_tokens=128, prefill_chunk_size=128
        ),
        execution_config=execution,
    )
    parameter = next(llm.engine.model_runner.model.parameters())
    assert parameter.dtype == torch.float32 and parameter.device.type == "cuda"
    install_neutral_counters(llm.engine)
    tokenizer = load_tokenizer(str(model), revision=PIN)
    ids = tokenizer.encode(
        "The scientist studied the stars and recorded the results. ", add_special_tokens=False
    )
    prompt = (ids * math.ceil(512 / len(ids)))[:512]
    prompts = [prompt.copy() for _ in range(concurrency)]
    manifest = dict(
        source_sha=SOURCE,
        protocol_sha256=digest(args.protocol),
        candidate_sha256=digest(args.candidate),
        arm=args.arm,
        fresh=args.fresh,
        B=batch,
        C=concurrency,
        requests_per_trial=concurrency,
        request_scope="INITIAL_C_TOTAL_C_NO_REFILL",
        instrumentation="NEUTRAL_CORE_HEAD_SCHEDULE_METADATA_WRAPPERS_ALL_ARMS",
        admission_timestamp_scope="SCHEDULE_RETURN_BEFORE_MODEL_EXECUTE",
        resident_observation_scope="POST_SCHEDULE_PRE_EXECUTE",
        kv_peak_observation_scope="SCHEDULE_CORE_CODA_POSTSTEP_METADATA",
        reference_peak_scope="ENGINE_LIFETIME",
        trial_observer_sha256=digest(ROOT / "scripts/fp32_candidate_cost_trial.py"),
        prefill_depth=4,
        decode_depth=depth,
        dtype="float32",
        attention_backend="triton",
        execution=asdict(execution),
        sampling=asdict(sampling),
        memory_plan=llm.engine.memory_plan,
        cache_config=asdict(cache_config),
        model_parameter_dtype=str(parameter.dtype),
        model_parameter_device=str(parameter.device),
        kv_num_blocks=llm.engine.cache_manager.num_blocks,
        kv_bytes_per_block=llm.engine.cache_manager.bytes_per_block,
        kv_pool_bytes=(
            llm.engine.cache_manager.num_blocks * llm.engine.cache_manager.bytes_per_block
        ),
        torch=torch.__version__,
        cuda=torch.version.cuda,
        device=torch.cuda.get_device_name(),
        prompt_sha256=hashlib.sha256(json.dumps(prompts).encode()).hexdigest(),
        scope=(
            "Native fixed-work cost; actual A/S/C required; no task-quality/HTTP/engine-async claim"
        ),
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with manifest_path.open("x") as stream:
        stream.write(json.dumps(manifest, indent=2) + "\n")
    try:
        run(llm.engine, prompts, sampling, concurrency, args.output, warmups=5, repetitions=5)
    finally:
        llm.close()


if __name__ == "__main__":
    main()
