"""Finite eager cost case; resume successful boundaries only under a new grant."""

import argparse
import datetime
import fcntl
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCKS = Path("/root/autodl-tmp/0z5a-coordination/h20")
SOURCE = "e8aa1ee57734bc5c1118c143ebdb68d0b53210a1"
PIN = "574fa66cb8bf5abdc979642d01cf2b79b16bfab1"
CUTOFF = datetime.datetime(2026, 10, 6, 0, 30, tzinfo=datetime.timezone.utc).timestamp()


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, record):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(record, indent=2) + "\n")
    temporary.replace(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--case", choices=("B16C32", "B32C64"), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--job-count", type=int, required=True)
    parser.add_argument("--budget-seconds", type=int, required=True)
    args = parser.parse_args()
    assert 1 <= args.job_count <= 6
    protocol, candidate = read(args.protocol), read(args.candidate)
    assert protocol["state"] == "FROZEN_FP32_CANDIDATE_COST"
    assert candidate["state"] == "PROVISIONAL_FOR_COST"
    assert protocol["source_sha"] == candidate["source_sha"] == SOURCE
    assert protocol["dtype"] == candidate["dtype"] == "float32"
    assert protocol["attention_backend"] == candidate["attention_backend"] == "triton"
    assert digest(args.candidate) == protocol["candidate_sha256"]
    forecast = args.budget_seconds
    assert forecast <= protocol["forecast_seconds_including_offbox"][args.case]
    job_forecast = protocol["forecast_one_job_seconds"][args.case]
    reserve = protocol["offbox_reserve_seconds"]
    assert reserve >= 180 and forecast >= job_forecast + reserve
    assert time.time() + forecast < CUTOFF
    assert sys.executable == str(ROOT / ".venv-canonical/bin/python")
    packages = {
        n: importlib.metadata.version(n)
        for n in ("torch", "triton", "transformers", "tokenizers", "safetensors", "huggingface-hub")
    }
    assert packages["transformers"] == "4.54.1" and packages["tokenizers"] == "0.21.4"
    script_sha = digest(Path(__file__))
    status_path = args.output / "status.json"
    if args.output.exists():
        record = read(status_path)
        assert record["status"] == "WAITING_NEXT_WINDOW"
        assert record["script_sha256"] == script_sha and record["packages"] == packages
        assert record["case"] == args.case and record["protocol_sha256"] == digest(args.protocol)
        assert record["candidate_sha256"] == digest(args.candidate)
        assert all(j["exit_code"] == 0 for j in record["jobs"])
    else:
        args.output.mkdir(parents=True, exist_ok=False)
        record = dict(
            status="WAITING",
            case=args.case,
            started=time.time(),
            jobs=[],
            sessions=[],
            source_sha=SOURCE,
            script_sha256=script_sha,
            packages=packages,
            protocol_sha256=digest(args.protocol),
            candidate_sha256=digest(args.candidate),
        )
    session = dict(
        pid=os.getpid(),
        started=time.time(),
        requested_jobs=args.job_count,
        granted_forecast_seconds=forecast,
    )
    record["sessions"].append(session)
    record.update(status="WAITING", pid=os.getpid())
    save(status_path, record)
    with (LOCKS / "gpu0.lock").open("r+") as gpu, (LOCKS / "io.lock").open("r+") as io:
        identities = [(os.fstat(f.fileno()).st_dev, os.fstat(f.fileno()).st_ino) for f in (gpu, io)]
        assert identities == [(64528, 12920245107), (64528, 12920245108)]
        fcntl.flock(gpu, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(io, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert time.time() + forecast < CUTOFF
        assert Path("/proc/sys/kernel/random/boot_id").read_text().strip() == (
            "797c630e-4da1-48bd-bdf3-daabf26649d2"
        )
        assert (
            subprocess.check_output(
                ["nvidia-smi", "--query-gpu=uuid", "--format=csv,noheader"], text=True
            ).strip()
            == "GPU-edf64e5f-21ef-a1f2-6601-e8620b5664ff"
        )
        assert not subprocess.check_output(
            ["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader"], text=True
        ).strip()
        assert (
            subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT / "source", text=True
            ).strip()
            == SOURCE
        )
        assert not subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=ROOT / "source", text=True
        ).strip()
        record.update(
            boot=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
            start_ticks=Path(f"/proc/{os.getpid()}/stat").read_text().split()[21],
            lock_identities=identities,
            inputs={},
        )
        session["start_ticks"] = record["start_ticks"]
        for name, sha in protocol["payload_hashes"].items():
            assert digest(ROOT / name) == sha, name
        gate_path = (
            ROOT
            / "evidence/qualification-w2-fp32-triton-v1/w2-fp32-triton-continuation/result.json"
        )
        gate = read(gate_path)
        assert digest(gate_path) == protocol["fp32_w2_gate_sha256"]
        assert gate["status"] == "PASS" and gate["atol"] == gate["rtol"] == 1e-4
        plan = read(ROOT / "evidence/model-input-plan.json")
        assert plan["revision"] == PIN and len(plan["files"]) == 11
        for entry in plan["files"]:
            path = ROOT / "models/ouro-574fa66c" / entry["rfilename"]
            assert path.stat().st_size == entry["size"]
            h = (
                hashlib.sha256()
                if "lfs" in entry
                else hashlib.sha1(f"blob {entry['size']}\0".encode())
            )
            with path.open("rb") as stream:
                for chunk in iter(lambda: stream.read(1024**2), b""):
                    h.update(chunk)
            expected = entry["lfs"]["sha256"] if "lfs" in entry else entry["blobId"]
            assert h.hexdigest() == expected, path
            record["inputs"][entry["rfilename"]] = expected
        environment = {
            **os.environ,
            "CUDA_VISIBLE_DEVICES": "0",
            "OMP_NUM_THREADS": "1",
            "MKL_NUM_THREADS": "1",
            "HF_HUB_OFFLINE": "1",
            "TRANSFORMERS_OFFLINE": "1",
            "HF_HUB_DISABLE_IMPLICIT_TOKEN": "1",
            "HF_HUB_DISABLE_XET": "1",
            "TOKENIZERS_PARALLELISM": "false",
            "PYTHONDONTWRITEBYTECODE": "1",
            "HF_HOME": str(ROOT / "cache/fp32-cost/huggingface"),
            "TRITON_CACHE_DIR": str(ROOT / "cache/fp32-cost/triton"),
            "PYTHONPATH": str(ROOT / "source") + ":" + str(ROOT / "scripts"),
        }
        order = [(0, "A"), (0, "B"), (0, "C"), (1, "C"), (1, "B"), (1, "A")]
        prior_count = len(record["jobs"])
        observed_max = max([j["finished"] - j["started"] for j in record["jobs"]] or [0])
        finite_deadline = min(CUTOFF, session["started"] + forecast)
        for index, (fresh, arm) in enumerate(order):
            label = f"{args.case}-fresh{fresh}-{arm}"
            if index < prior_count:
                assert record["jobs"][index]["name"] == label
                continue
            next_forecast = max(job_forecast, observed_max * 1.5)
            if (
                index >= prior_count + args.job_count
                or time.time() + next_forecast + reserve >= finite_deadline
            ):
                session.update(
                    finished=time.time(), completed_jobs=len(record["jobs"]) - prior_count
                )
                record.update(status="WAITING_NEXT_WINDOW", finished=time.time())
                save(status_path, record)
                return 0
            command = [
                sys.executable,
                str(ROOT / "scripts/draft_fp32_candidate_cost.py"),
                "--protocol",
                str(args.protocol),
                "--candidate",
                str(args.candidate),
                "--case",
                args.case,
                "--fresh",
                str(fresh),
                "--arm",
                arm,
                "--output",
                str(args.output / label),
            ]
            job = dict(
                name=label, command=command, started=time.time(), forecast_seconds=next_forecast
            )
            record["jobs"].append(job)
            with (args.output / (label + ".log")).open("x") as log:
                child = subprocess.Popen(
                    command,
                    cwd=ROOT / "source",
                    env=environment,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                )
                job.update(
                    pid=child.pid,
                    start_ticks=Path(f"/proc/{child.pid}/stat").read_text().split()[21],
                )
                record["status"] = "RUNNING"
                save(status_path, record)
                job.update(exit_code=child.wait(), finished=time.time())
            observed_max = max(observed_max, job["finished"] - job["started"])
            save(status_path, record)
            if job["exit_code"]:
                session.update(finished=time.time(), failed_job=label)
                record.update(status="FAILED", finished=time.time())
                save(status_path, record)
                return job["exit_code"]
        session.update(finished=time.time(), completed_jobs=len(record["jobs"]) - prior_count)
        record.update(status="COMPLETE", finished=time.time())
        save(status_path, record)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
