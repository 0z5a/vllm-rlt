"""Private eager cost observer; original native trial plus neutral row/head counters.

The original production methods and capability-gated LoopCD statistics remain
unchanged. All three arms receive these same metadata-only wrappers. Original
method arguments/results are forwarded directly without new CUDA operations.
"""

import json
import math
import statistics
import time
from collections import Counter

import torch
from vllm_rlt.request import Stage


def install_neutral_counters(engine):
    runner = engine.model_runner
    assert not hasattr(runner, "cost_neutral_stats")
    assert runner.execution_config.cuda_graphs is False
    assert runner.execution_config.async_scheduling is False
    runner.cost_observer_context = None
    runner.cost_neutral_stats = dict(
        prefill_core_rows=0,
        prefill_submitted_rows=0,
        decode_core_rows=0,
        decode_submitted_rows=0,
        head_calls=0,
        head_rows=0,
    )
    original_count = runner._count_core
    original_coda = runner.model.coda
    original_schedule = engine.scheduler.schedule

    def sample_metadata(*, admission=False):
        context = runner.cost_observer_context
        if context is None:
            return
        context["kv_peak_blocks"] = max(
            context["kv_peak_blocks"], engine.cache_manager.num_used_blocks
        )
        if not admission:
            return
        context["schedule_calls"] += 1
        now = time.perf_counter() - context["start"]
        requests = engine.scheduler.requests
        occupied = sum(r.stage not in (Stage.WAITING, Stage.RECEIVING) for r in requests.values())
        context["resident_histogram"][occupied] += 1
        for rid, request in requests.items():
            row = context["traces"][context["active"][rid]]
            if request.stage not in (Stage.WAITING, Stage.RECEIVING) and row["admitted_s"] is None:
                row["admitted_s"] = now
                row["admission_boundary"] = "SCHEDULE_RETURN_BEFORE_MODEL_EXECUTE"

    def schedule(*args, **kwargs):
        result = original_schedule(*args, **kwargs)
        sample_metadata(admission=True)
        return result

    def count_core(effective, submitted, *, prefill=False):
        result = original_count(effective, submitted, prefill=prefill)
        phase = "prefill" if prefill else "decode"
        runner.cost_neutral_stats[phase + "_core_rows"] += effective
        runner.cost_neutral_stats[phase + "_submitted_rows"] += submitted
        sample_metadata()
        return result

    def coda(hidden):
        result = original_coda(hidden)
        runner.cost_neutral_stats["head_calls"] += 1
        runner.cost_neutral_stats["head_rows"] += hidden.shape[0]
        sample_metadata()
        return result

    runner._count_core = count_core
    runner.model.coda = coda
    engine.scheduler.schedule = schedule


def distribution(values):
    ordered = sorted(values)
    return {
        "n": len(values),
        "mean": statistics.mean(values),
        "median": statistics.median(values),
        "p95": ordered[math.ceil(0.95 * len(values)) - 1],
        "p99": ordered[math.ceil(0.99 * len(values)) - 1],
        "min": ordered[0],
        "max": ordered[-1],
    }


def graph_counts(engine):
    bank = engine.model_runner.graphs
    return (
        dict(captures=bank.captures, replays=bank.replays, fallbacks=bank.fallbacks)
        if bank
        else dict(captures=0, replays=0, fallbacks=0)
    )


def synchronize(engine):
    if engine.model_runner.device.type == "cuda":
        torch.cuda.synchronize(engine.model_runner.device)


@torch.inference_mode()
def trial(engine, prompts, sampling, concurrency):
    """Refill reused IDs only after consuming the complete output batch."""
    if engine.has_unfinished_requests() or engine.cache_manager.num_used_blocks:
        raise ValueError("trial requires a drained engine")
    if not 1 <= concurrency <= len(prompts) or sampling.max_tokens < 2:
        raise ValueError("require 1 <= C <= requests and at least two output tokens")
    if not sampling.ignore_eos or sampling.min_loops != sampling.max_loops:
        raise ValueError("fixed work requires ignore_eos and fixed decode depth")
    runner, cache = engine.model_runner, engine.cache_manager
    before_graph = graph_counts(engine)
    before_work = dict(runner.loopcd_stats)
    before_neutral = dict(runner.cost_neutral_stats)
    synchronize(engine)
    if runner.device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(runner.device)
    start = time.perf_counter()
    active, traces, free = {}, {}, list(range(concurrency))
    next_request = kv_peak = 0
    previous_decode_rows = 0
    resident, outstanding, core_rows = Counter(), Counter(), Counter()
    resident_poststep = Counter()
    runner.cost_observer_context = dict(
        start=start,
        active=active,
        traces=traces,
        resident_histogram=resident,
        kv_peak_blocks=0,
        schedule_calls=0,
    )
    phases = Counter()

    def fill():
        nonlocal next_request
        while free and next_request < len(prompts):
            slot = free.pop()
            rid = f"slot-{slot}"
            prompt = prompts[next_request]
            engine.add_request(rid, prompt, sampling)
            active[rid] = next_request
            traces[next_request] = dict(
                ordinal=next_request,
                request_id=rid,
                prompt=prompt,
                submitted_s=time.perf_counter() - start,
                admitted_s=None,
                token_ids=[],
                exit_depths=[],
                delivery_s=[],
            )
            next_request += 1

    fill()
    bound = len(prompts) * (
        max(map(len, prompts)) * engine.prefill_depth
        + sampling.max_tokens * (sampling.max_loops + 4)
        + 10
    )
    for _ in range(bound):
        outstanding[len(active)] += 1
        outputs = engine.step()
        now = time.perf_counter() - start
        requests = engine.scheduler.requests
        resident_poststep[
            sum(r.stage not in (Stage.WAITING, Stage.RECEIVING) for r in requests.values())
        ] += 1
        schedule = engine.last_schedule
        if schedule is not None:
            phases[f"{schedule.stage.value}:{len(schedule.items)}"] += 1
        work = runner.cost_neutral_stats
        submitted = work["decode_core_rows"] - before_neutral["decode_core_rows"]
        # Counts are taken from actual model runner row counters, not B/C settings.
        if submitted != previous_decode_rows:
            core_rows[submitted - previous_decode_rows] += 1
            previous_decode_rows = submitted
        kv_peak = max(
            kv_peak, cache.num_used_blocks, runner.cost_observer_context["kv_peak_blocks"]
        )
        released = []
        for output in outputs:
            row = traces[active[output.request_id]]
            count = len(row["token_ids"])
            if (
                output.prompt_token_ids != row["prompt"]
                or output.token_ids[:count] != row["token_ids"]
            ):
                raise RuntimeError("request identity or output prefix changed")
            row["delivery_s"].extend([now] * (len(output.token_ids) - count))
            row["token_ids"], row["exit_depths"] = output.token_ids, output.exit_depths
            if output.finished:
                expected = [engine.prefill_depth] + [sampling.max_loops] * (sampling.max_tokens - 1)
                if (
                    len(output.token_ids) != sampling.max_tokens
                    or output.exit_depths != expected
                    or output.finish_reason != "length"
                ):
                    raise RuntimeError("fixed work/depth/finish contract failed")
                row.update(finished_s=now, finish_reason=output.finish_reason)
                released.append(int(output.request_id.split("-")[1]))
                del active[output.request_id]
        free.extend(sorted(released))
        fill()
        if not active:
            break
    else:
        raise RuntimeError("finite work bound exhausted")
    synchronize(engine)
    elapsed = time.perf_counter() - start
    runner.cost_observer_context = None
    if engine.has_unfinished_requests() or cache.num_used_blocks or runner.loopcd_references:
        raise RuntimeError("KV/reference/request leak after drain")
    rows = [traces[i] for i in range(len(prompts))]
    after_graph = graph_counts(engine)
    return dict(
        elapsed_s=elapsed,
        tps=len(prompts) * sampling.max_tokens / elapsed,
        rps=len(prompts) / elapsed,
        requests=rows,
        ttft_s=distribution([r["delivery_s"][0] - r["submitted_s"] for r in rows]),
        latency_s=distribution([r["finished_s"] - r["submitted_s"] for r in rows]),
        tpot_s=distribution(
            [(r["delivery_s"][-1] - r["delivery_s"][0]) / (sampling.max_tokens - 1) for r in rows]
        ),
        itl_s=distribution(
            [b - a for r in rows for a, b in zip(r["delivery_s"], r["delivery_s"][1:])]
        ),
        admission_wait_s=distribution([r["admitted_s"] - r["submitted_s"] for r in rows]),
        resident_histogram=dict(resident),
        resident_poststep_histogram=dict(resident_poststep),
        admission_timestamp_scope="SCHEDULE_RETURN_BEFORE_MODEL_EXECUTE",
        resident_observation_scope="POST_SCHEDULE_PRE_EXECUTE",
        kv_peak_observation_scope="SCHEDULE_CORE_CODA_POSTSTEP_METADATA",
        outstanding_histogram=dict(outstanding),
        decode_effective_rows_histogram=dict(core_rows),
        schedule_histogram=dict(phases),
        kv_peak_blocks=kv_peak,
        kv_pool_bytes=cache.num_blocks * cache.bytes_per_block,
        loopcd_work={
            k: v - before_work[k]
            for k, v in runner.loopcd_stats.items()
            if k != "reference_peak_bytes"
        },
        neutral_core_head_work={
            k: v - before_neutral[k] for k, v in runner.cost_neutral_stats.items()
        },
        reference_peak_bytes=runner.loopcd_stats["reference_peak_bytes"],
        graph={k: after_graph[k] - before_graph[k] for k in after_graph},
        peak_allocated_bytes=torch.cuda.max_memory_allocated(runner.device)
        if runner.device.type == "cuda"
        else None,
        peak_reserved_bytes=torch.cuda.max_memory_reserved(runner.device)
        if runner.device.type == "cuda"
        else None,
        drained=True,
    )


def signature(result):
    return [
        (r["ordinal"], r["request_id"], r["token_ids"], r["exit_depths"], r["finish_reason"])
        for r in result["requests"]
    ]


def run(engine, prompts, sampling, concurrency, output, warmups=5, repetitions=5):
    output.mkdir(parents=True, exist_ok=False)
    expected = None
    summary = []
    for index in range(warmups + repetitions):
        result = trial(engine, prompts, sampling, concurrency)
        result.update(index=index, phase="warmup" if index < warmups else "measured")
        current = signature(result)
        if expected is not None and current != expected:
            result["repeat_parity"] = False
        else:
            result["repeat_parity"] = True
        expected = current
        (output / f"trial-{index:02d}.json").write_text(json.dumps(result, indent=2) + "\n")
        if not result["repeat_parity"]:
            raise RuntimeError("repeat token/depth/ID/finish mismatch; raw result preserved")
        if index >= warmups and result["graph"]["captures"]:
            raise RuntimeError("cold graph capture during measured work; raw result preserved")
        summary.append({k: v for k, v in result.items() if k != "requests"})
        print(
            json.dumps(
                {"index": index, "phase": result["phase"], "tps": result["tps"], "drained": True}
            ),
            flush=True,
        )
    (output / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
