"""Finite Re:Loop quality window; children exit naturally and evidence stays local."""

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path


def dump(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--support", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    args = parser.parse_args()
    work = args.work
    ready = json.loads((work / "ready.json").read_text())
    assert ready["w2_gate"]["status"] == "PASS"
    assert ready["w2_gate"]["dtype"] == "float32"
    assert ready["w2_gate"]["attention_backend"] == "triton"
    plan = json.loads((work / "data/development-math-plan.json").read_text())
    assert time.time() + 600 < plan["archive_by_unix"]
    evidence = work / "evidence"
    evidence.mkdir(exist_ok=True)
    receipt = {
        "pid": os.getpid(),
        "started_unix": time.time(),
        "children": [],
        "archive_by_unix": plan["archive_by_unix"],
        "status": "RUNNING",
    }
    receipt_path = evidence / "window.json"
    dump(receipt_path, receipt)
    env = dict(
        os.environ,
        PYTHONDONTWRITEBYTECODE="1",
        PYTHONPYCACHEPREFIX=str(work / "cache/python"),
        CUDA_VISIBLE_DEVICES="",
        HF_HUB_OFFLINE="1",
        TRANSFORMERS_OFFLINE="1",
        HF_HOME=str(work / "cache/hf"),
        XDG_CACHE_HOME=str(work / "cache"),
        CUDA_CACHE_PATH=str(work / "cache/cuda"),
        TORCH_HOME=str(work / "cache/torch"),
        TORCHINDUCTOR_CACHE_DIR=str(work / "cache/inductor"),
        TRITON_CACHE_DIR=str(work / "cache/triton"),
    )

    def child(
        name: str, arguments: list[str], cuda: bool = False, python: Path | None = None
    ) -> int:
        assert time.time() + 600 < plan["archive_by_unix"]
        with (evidence / f"{name}.log").open("x") as log:
            process = subprocess.Popen(
                [str(python or args.python), *arguments],
                stdout=log,
                stderr=subprocess.STDOUT,
                env={**env, "CUDA_VISIBLE_DEVICES": "0" if cuda else ""},
            )
            record = {"name": name, "pid": process.pid, "started_unix": time.time()}
            receipt["children"].append(record)
            dump(receipt_path, receipt)
            record.update(returncode=process.wait(), finished_unix=time.time())
            dump(receipt_path, receipt)
            return record["returncode"]

    audit_python = Path("/root/miniconda3/bin/python")
    scipy_available = (
        subprocess.check_output(
            [
                str(audit_python),
                "-c",
                "import importlib.util; print(importlib.util.find_spec('scipy') is not None)",
            ],
            env=env,
            text=True,
        ).strip()
        == "True"
    )
    if scipy_available:
        receipt["cp_audit_returncode"] = child(
            "paired-scipy-audit",
            [
                str(work / "harness/audit_paired_scipy.py"),
                "--source",
                str(work / "harness/paired_quality.py"),
                "--output",
                str(evidence / "paired-scipy-audit.json"),
            ],
            python=audit_python,
        )
    else:
        dump(
            evidence / "paired-scipy-audit.json",
            {"status": "NOT_RUN", "reason": "no existing SciPy; no environment change"},
        )

    driver = str(work / "harness/generate_quality.py")
    common = ["--source", str(args.source), "--support", str(args.support)]
    frozen = evidence / "development-frozen.json"
    code = child(
        "tokenize",
        [
            driver,
            "tokenize",
            *common,
            "--plan",
            str(work / "data/development-math-plan.json"),
            "--data",
            str(work / "data/development-math.json"),
            "--output",
            str(frozen),
        ],
    )
    if code == 0:
        mini = json.loads(frozen.read_text())
        mini.update(
            stage="qualification",
            records=mini["records"][:2],
            max_new_tokens=32,
            generated_token_budget=384,
            gpu_residence_budget_seconds=600,
        )
        mini_path = evidence / "driver-qualification.json"
        dump(mini_path, mini)
        code = child(
            "driver-qualification",
            [
                driver,
                "generate",
                *common,
                "--plan",
                str(mini_path),
                "--output",
                str(evidence / "qualification"),
            ],
            True,
        )
    if code == 0:
        code = child(
            "development",
            [
                driver,
                "generate",
                *common,
                "--plan",
                str(frozen),
                "--output",
                str(evidence / "development"),
            ],
            True,
        )
    if code == 0:
        code = child(
            "score-math",
            [
                str(work / "harness/score_math.py"),
                "--plan",
                str(frozen),
                "--records",
                str(evidence / "development/records.jsonl"),
                "--out",
                str(evidence / "development-scored.json"),
            ],
        )
    receipt.update(
        status="COMPLETE" if code == 0 else "FAILED",
        returncode=code,
        finished_unix=time.time(),
    )
    dump(receipt_path, receipt)
    subprocess.run(
        ["git", "bundle", "create", str(work / "source.bundle"), "HEAD"],
        cwd=args.source,
        check=True,
    )
    payload = []
    for path in sorted(work.rglob("*")):
        if path.is_file() and "cache" not in path.relative_to(work).parts:
            payload.append(
                {
                    "path": str(path.relative_to(work)),
                    "bytes": path.stat().st_size,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
            )
    dump(work / "raw-manifest.json", {"files": payload})
    print(json.dumps(receipt), flush=True)
    raise SystemExit(code)


if __name__ == "__main__":
    main()
