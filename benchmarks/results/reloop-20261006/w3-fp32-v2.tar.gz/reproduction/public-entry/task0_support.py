"""Private Task0 Ouro validation support, outside the published production tree.

Frozen native driver/likelihood/numeric metrics from research 74547e4.
Only config/family/layer accounting are narrowed to public Ouro d700ecca.
"""

import json
import os
import statistics
import tempfile
import time
from dataclasses import fields, replace
from pathlib import Path

from benchmarks.gsm8k import digest, file_digest


def verify_public_source():
    """Check the loaded native package against the complete public source tree."""
    import vllm_rlt

    source = Path(vllm_rlt.__file__).resolve().parents[1]
    manifest_path = Path(__file__).with_name("public-source-manifest.json")
    manifest = json.loads(manifest_path.read_text())
    if manifest["head"] != "d700ecca664da2e8f3122f66ad9d45de4295e45a":
        raise ValueError("official Task0 requires the exact public source pin")
    for name, expected in manifest["files"].items():
        path = source / name
        if path.is_symlink() or not path.is_file() or file_digest(path) != expected:
            raise ValueError(f"public Task0 source mismatch: {name}")
    return {
        "head": manifest["head"],
        "tree": manifest["tree"],
        "package_root": str(source),
        "files_verified": len(manifest["files"]),
        "manifest_sha256": file_digest(manifest_path),
    }


def write_json(path, data):
    """Atomically persist progress; completed record names remain caller-owned."""
    fd, temporary = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    with os.fdopen(fd, "w") as stream:
        json.dump(data, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def exact(value, keys, name):
    if not isinstance(value, dict) or set(value) != set(keys):
        raise ValueError(
            f"{name}: required fields {sorted(keys)}; unknown/missing fields rejected"
        )


def config(cls, values):
    exact(values, [field.name for field in fields(cls)], cls.__name__)
    return cls(**values)


def validate(protocol):
    from vllm_rlt import (
        CacheConfig,
        ExecutionConfig,
        LoopCDParams,
        SamplingParams,
        SchedulerConfig,
    )

    exact(
        protocol,
        (
            "format_version",
            "family",
            "model",
            "dtype",
            "cache",
            "scheduler",
            "execution",
            "attention_backend",
            "initialization",
            "task",
            "records",
            "timing",
            "arms",
            "thresholds",
        ),
        "protocol",
    )
    if protocol["format_version"] != 1 or protocol["family"] != "ouro":
        raise ValueError("unsupported protocol/model family")
    if protocol["dtype"] not in ("float32", "float16", "bfloat16"):
        raise ValueError("unsupported dtype")
    exact(protocol["model"], ("path", "repo", "revision", "files"), "model")
    model = protocol["model"]
    if (
        len(model["revision"]) != 40
        or not model["files"]
        or "config.json" not in model["files"]
    ):
        raise ValueError("pin the checkpoint revision and complete file manifest")
    for name, sha in model["files"].items():
        if Path(name).name != name or len(sha) != 64:
            raise ValueError("invalid checkpoint file manifest")
    cache = config(CacheConfig, protocol["cache"])
    scheduler = config(SchedulerConfig, protocol["scheduler"])
    execution = config(ExecutionConfig, protocol["execution"])
    if cache.num_blocks is None and cache.kv_cache_memory_bytes is None:
        raise ValueError("paired engines require an explicit common KV budget")
    if (
        cache.layout != "last_exited"
        or cache.enable_prefix_caching
        or scheduler.enable_preemption
        or execution.async_scheduling
        or execution.prefill_uva
        or not execution.loopcd
        or execution.prefill_depth is not None
    ):
        raise ValueError(
            "use reserved synchronous last_exited; specify prefill depth in each arm"
        )
    if protocol["attention_backend"] not in (
        "torch",
        "triton",
        "flash_attn",
        "flash_attn_4",
    ):
        raise ValueError("unsupported attention backend")
    exact(protocol["initialization"], ("protocol", "seed"), "initialization")
    init = protocol["initialization"]
    expected = "not_applicable"
    if (
        init["protocol"] != expected
        or type(init["seed"]) is not int
        or not 0 <= init["seed"] < 2**63
    ):
        raise ValueError("missing/unsupported initialization protocol")
    exact(
        protocol["task"],
        (
            "kind",
            "dataset_repo",
            "dataset_revision",
            "split",
            "selection",
            "evaluator_version",
            "task_config",
            "records_sha256",
            "length_normalization",
        ),
        "task",
    )
    task = protocol["task"]
    if task["kind"] not in (
        "fixed_workload",
        "gsm8k",
        "evalplus_export",
        "multiple_choice",
    ):
        raise ValueError("unsupported task scorer")
    if (
        not task["dataset_revision"]
        or not task["evaluator_version"]
        or task["length_normalization"] not in ("sum", "token_mean")
    ):
        raise ValueError("freeze dataset/evaluator and likelihood length normalization")
    records = protocol["records"]
    if not records or task["records_sha256"] != digest(records):
        raise ValueError("missing/changed frozen records")
    ids = []
    for row in records:
        exact(
            row,
            ("id", "prompt_ids", "stop", "doc", "candidates", "correct_index"),
            "record",
        )
        ids.append(row["id"])
        token_lists = [row["prompt_ids"], *row["candidates"]]
        if any(
            not values or any(type(t) is not int or t < 0 for t in values)
            for values in token_lists
        ):
            raise ValueError("record token lists must be nonempty integer lists")
        if any(not isinstance(stop, str) or not stop for stop in row["stop"]):
            raise ValueError("invalid text stop")
        if task["kind"] == "multiple_choice":
            if (
                len(row["candidates"]) < 2
                or type(row["correct_index"]) is not int
                or not 0 <= row["correct_index"] < len(row["candidates"])
            ):
                raise ValueError(
                    "multiple choice requires all tokenized candidates and answer index"
                )
        elif row["candidates"] or row["correct_index"] is not None:
            raise ValueError("generation records cannot contain likelihood candidates")
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate record IDs")
    exact(
        protocol["timing"], ("warmups", "pairs", "batch_sizes", "ignore_eos"), "timing"
    )
    timing = protocol["timing"]
    if (
        type(timing["warmups"]) is not int
        or timing["warmups"] < 5
        or type(timing["pairs"]) is not int
        or not 5 <= timing["pairs"] <= 20
        or timing["batch_sizes"] != [1, 4]
        or timing["ignore_eos"] is not True
    ):
        raise ValueError(
            "fixed-work timing requires >=5 warmups, 5..20 pairs and B=1/4"
        )
    exact(
        protocol["thresholds"], ("max_regression_pp", "min_speed_ratio"), "thresholds"
    )
    if not (
        0 <= protocol["thresholds"]["max_regression_pp"] <= 100
        and protocol["thresholds"]["min_speed_ratio"] > 0
    ):
        raise ValueError("invalid predeclared quality/cost thresholds")
    if len(protocol["arms"]) != 2:
        raise ValueError("exactly two paired arms are required")
    names = []
    for arm in protocol["arms"]:
        exact(arm, ("name", "prefill_depth", "sampling"), "arm")
        names.append(arm["name"])
        if type(arm["prefill_depth"]) is not int or arm["prefill_depth"] < 1:
            raise ValueError("invalid actual prefill depth")
        values = dict(arm["sampling"])
        exact(
            values, [field.name for field in fields(SamplingParams)], "SamplingParams"
        )
        if values["loopcd"] is not None:
            values["loopcd"] = config(LoopCDParams, values["loopcd"])
        sampling = config(SamplingParams, values)
        if sampling.min_loops != sampling.max_loops or sampling.exit_threshold != 1:
            raise ValueError("paired arms must execute fixed decode depth")
        cd = sampling.loopcd
        if cd is not None:
            if not (
                cd.reference_loop < sampling.max_loops
                and cd.prefill_loop < arm["prefill_depth"]
            ):
                raise ValueError("reference must precede actual prefill/decode depth")
            mode = "logits"
            if cd.mode != mode:
                raise ValueError("model/mode combination unsupported")
        if sampling.ignore_eos:
            raise ValueError(
                "quality uses natural EOS; fixed-work timing overrides it explicitly"
            )
        if (
            task["kind"] == "multiple_choice"
            and max(len(c) for row in records for c in row["candidates"])
            > sampling.max_tokens
        ):
            raise ValueError("candidate exceeds declared output budget")
    if len(set(names)) != 2 or any(
        not isinstance(name, str) or not name for name in names
    ):
        raise ValueError("arms require distinct nonempty names")
    return protocol


def sampling_for(arm):
    from vllm_rlt import LoopCDParams, SamplingParams

    values = dict(arm["sampling"])
    if values["loopcd"] is not None:
        values["loopcd"] = LoopCDParams(**values["loopcd"])
    return SamplingParams(**values)


def graph_counts(engine):
    graph = engine.model_runner.graphs
    return (
        dict(captures=graph.captures, replays=graph.replays, fallbacks=graph.fallbacks)
        if graph
        else dict(captures=0, replays=0, fallbacks=0)
    )


def synchronize(engine):
    import torch

    if engine.model_runner.device.type == "cuda":
        torch.cuda.synchronize(engine.model_runner.device)


def drive(
    engine,
    prompts,
    sampling,
    seed,
    *,
    observer=None,
    tokenizer=None,
    stops=(),
    profile=False,
):
    """Native engine driver; observers belong only to quality/oracles."""
    import torch

    if engine.has_unfinished_requests():
        raise RuntimeError("paired engine has unfinished requests")
    torch.manual_seed(seed)
    runner = engine.model_runner
    original = runner._sample_tensor
    if observer is not None:

        def observed(logits, request):
            if not torch.isfinite(logits).all().item():
                raise FloatingPointError("non-finite quality logits")
            result = observer(logits, request)
            return original(logits, request) if result is None else result

        runner._sample_tensor = observed
    before = graph_counts(engine)
    work_before = dict(runner.loopcd_stats)
    finished, emission = {}, {str(i): [] for i in range(len(prompts))}
    synchronize(engine)
    started = time.perf_counter()
    phase_events, phase_host_seconds = [], {}
    bound = (
        sum(len(p) for p in prompts)
        + len(prompts)
        * sampling.max_tokens
        * (max(engine.prefill_depth, sampling.max_loops) + 4)
        + 100
    )
    try:
        for i, prompt in enumerate(prompts):
            engine.add_request(str(i), prompt, sampling)
        for step in range(bound):
            begin = end = None
            if profile and runner.device.type == "cuda":
                begin, end = (
                    torch.cuda.Event(enable_timing=True),
                    torch.cuda.Event(enable_timing=True),
                )
                begin.record()
            step_started = time.perf_counter() if profile else 0
            outputs = engine.step()
            if profile:
                phase = engine.last_schedule.stage.value
                phase_host_seconds[phase] = (
                    phase_host_seconds.get(phase, 0)
                    + time.perf_counter()
                    - step_started
                )
                if end is not None:
                    end.record()
                    phase_events.append((phase, begin, end))
            for out in outputs:
                emission[out.request_id].append(
                    (len(out.token_ids), time.perf_counter() - started)
                )
                if (
                    not out.finished
                    and stops
                    and any(
                        stop
                        in tokenizer.decode(out.token_ids, skip_special_tokens=True)
                        for stop in stops
                    )
                ):
                    out = engine.abort_request(out.request_id)
                    finished[out.request_id] = dict(
                        token_ids=out.token_ids,
                        exit_depths=out.exit_depths,
                        finish_reason="stop_text",
                    )
                elif out.finished:
                    finished[out.request_id] = dict(
                        token_ids=out.token_ids,
                        exit_depths=out.exit_depths,
                        finish_reason=out.finish_reason,
                    )
            if not engine.has_unfinished_requests():
                break
        else:
            raise RuntimeError(
                "finite stage budget exhausted without interrupting a running step"
            )
        synchronize(engine)
        seconds = time.perf_counter() - started
        if (
            len(finished) != len(prompts)
            or runner.loopcd_references
            or engine.cache_manager.num_used_blocks
        ):
            raise RuntimeError("incomplete generation or leaked reference/KV")
    finally:
        runner._sample_tensor = original
        for request_id in list(engine.scheduler.requests):
            engine.abort_request(request_id)
    after = graph_counts(engine)
    work = {
        k: v - work_before[k]
        for k, v in runner.loopcd_stats.items()
        if k != "reference_peak_bytes"
    }
    work["reference_peak_bytes_process"] = runner.loopcd_stats["reference_peak_bytes"]
    layers = engine.model.config.num_hidden_layers
    work["completed_core_layer_tokens"] = (
        work["prefill_core_rows"] + work["decode_core_rows"]
    ) * layers
    work["padded_core_rows"] = (
        work["prefill_submitted_rows"]
        + work["decode_submitted_rows"]
        - work["prefill_core_rows"]
        - work["decode_core_rows"]
    )
    work["prefill_token_rows"] = sum(map(len, prompts))
    work["decode_prelude_token_rows"] = sum(
        len(out["token_ids"]) - 1 for out in finished.values()
    )
    phase_gpu_seconds = {}
    for phase, begin, end in phase_events:
        phase_gpu_seconds[phase] = (
            phase_gpu_seconds.get(phase, 0) + begin.elapsed_time(end) / 1000
        )
    return dict(
        seconds=seconds,
        steps=step + 1,
        outputs=finished,
        emission=emission,
        work=work,
        graph_delta={key: after[key] - before[key] for key in before},
        kv_used_blocks_after=0,
        diagnostic_phase_host_seconds=phase_host_seconds,
        diagnostic_phase_gpu_seconds=phase_gpu_seconds,
    )


def loglikelihood(engine, prompt, continuation, sampling, seed, *, capture=None):
    """Score every candidate token, including the prefill's first readout."""
    import torch

    if not continuation:
        raise ValueError("likelihood candidate cannot be empty")
    values = []

    def force(logits, request):
        index = request.num_scheduled_outputs
        token = continuation[index]
        if capture is not None:
            capture(logits, index)
        values.append(logits.float().log_softmax(-1)[token].item())
        return torch.tensor(token, device=logits.device, dtype=torch.long)

    result = drive(
        engine,
        [prompt],
        replace(sampling, max_tokens=len(continuation), ignore_eos=True),
        seed,
        observer=force,
    )
    if result["outputs"]["0"]["token_ids"] != continuation or len(values) != len(
        continuation
    ):
        raise RuntimeError("teacher-forced history does not match all candidate tokens")
    return dict(
        token_logprobs=values,
        sum_logprob=sum(values),
        token_mean_logprob=statistics.mean(values),
        exit_depths=result["outputs"]["0"]["exit_depths"],
        work=result["work"],
    )


def numeric_metrics(reference, candidate, selected):
    """Same-prefix logits, not strings: BF16 rounding is reported, not hidden."""
    import torch

    if reference.shape != candidate.shape or reference.ndim != 2:
        raise ValueError(
            "numeric comparison requires matching token-by-vocabulary logits"
        )
    a, b = reference.float(), candidate.float()
    if not torch.isfinite(a).all() or not torch.isfinite(b).all():
        raise FloatingPointError("non-finite numerical oracle logits")
    error = (a - b).abs().flatten()
    flips = a.argmax(-1) != b.argmax(-1)
    top = a.topk(2, dim=-1).values
    margins = top[:, 0] - top[:, 1]
    selected = torch.as_tensor(selected, device=a.device, dtype=torch.long)[:, None]
    logprob = (
        a.log_softmax(-1).gather(1, selected) - b.log_softmax(-1).gather(1, selected)
    ).abs()
    return dict(
        max_abs=error.max().item(),
        mean_abs=error.mean().item(),
        p95_abs=error.quantile(0.95).item(),
        p99_abs=error.quantile(0.99).item(),
        top1_flip_rate=flips.float().mean().item(),
        flip_token_indices=flips.nonzero().flatten().tolist(),
        reference_top2_margins_at_flips=margins[flips].tolist(),
        max_selected_logprob_error=logprob.max().item(),
    )


def is_folding_pair(protocol):
    a, b = protocol["arms"]
    if protocol["family"] != "ouro" or a["prefill_depth"] != b["prefill_depth"]:
        return False
    values = [json.loads(json.dumps(arm["sampling"])) for arm in (a, b)]
    if any(value["loopcd"] is None for value in values):
        return False
    implementations = [value["loopcd"].pop("implementation") for value in values]
    return (
        set(implementations) == {"two_head", "linear_fused"} and values[0] == values[1]
    )


def verify_checkpoint(model):
    folder = Path(model["path"])
    manifest = model["files"]
    present = {p.name for p in folder.iterdir() if p.is_file()}
    if present != set(manifest) or not any(
        name.endswith(".safetensors") for name in present
    ):
        raise ValueError(
            "model/tokenizer file coverage differs from the pinned manifest"
        )
    for name, sha in manifest.items():
        if file_digest(folder / name) != sha:
            raise ValueError(f"checkpoint file changed: {name}")
    return folder
